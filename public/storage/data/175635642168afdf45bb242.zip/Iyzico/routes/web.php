<?php

use Illuminate\Support\Facades\Route;
use Modules\Iyzico\Http\Controllers\IyzicoController;


Route::middleware(['XSS'])->group(function () {

Route::get('/admin/iyzico-settings', [IyzicoController::class, 'iyzico_settings']);
Route::post('/admin/iyzico-settings', [IyzicoController::class, 'update_iyzico_settings'])->name('admin.iyzico-settings');
Route::post('/iyzico-success/{ord_token}', [IyzicoController::class, 'iyzico_success'])->name('iyzico-success');
Route::post('/iyzico-subscription/{ord_token}', [IyzicoController::class, 'iyzico_subscription'])->name('iyzico-subscription');

});
