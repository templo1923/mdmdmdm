<?php

namespace Modules\ExtraServices\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\UddoktaPay\Database\Factories\UddoktaPayFactory;

class Extra extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    public static function xtra_Settings()
    {

    $value=DB::table('addon_extra_services')->where('extra_service_id','=',1)->first(); 
    return $value;
	
    }
	
	public static function update_extra_Settings($data)
	{
    DB::table('addon_extra_services')
      ->where('extra_service_id', 1)
      ->update($data);
    }
	
	public static function xtra_Category()
   {

    $value=DB::table('addon_extra_services_category')->where('ex_service_drop_status','=','no')->orderBy('ex_service_order', 'asc')->get(); 
    return $value;
	
   }
   
   public static function xtra_product_show()
   {

    $value=DB::table('addon_extra_services_category')->where('ex_service_drop_status','=','no')->where('ex_service_status','=',1)->orderBy('ex_service_order', 'asc')->get(); 
    return $value;
	
   }
   
   public static function save_xtra_Category($data){
   
      DB::table('addon_extra_services_category')->insert($data);
     
 
    }	
	
	public static function delete_xtra_category($token,$data)
	{
	   
	   DB::table('addon_extra_services_category')
      ->where('ex_service_id', $token)
      ->update($data);
	
	}
	
	
	 public static function edit_xtra_category($token){
		$value = DB::table('addon_extra_services_category')
		  ->where('ex_service_id', $token)
		  ->first();
		return $value;
	  }
	  
	  
	public static function update_xtra_category($ex_service_id,$data)
	{
	   
	   DB::table('addon_extra_services_category')
      ->where('ex_service_id', $ex_service_id)
      ->update($data);
	
	}  
	
	public static function save_xtra_Product($data){
   
      DB::table('addon_extra_services_product')->insert($data);
     
 
    }
	
	public static function delete_xtra_Product($product_token)
	{
    
	DB::table('addon_extra_services_product')->where('ex_product_token', '=', $product_token)->delete();	
	
	
    }
	
	public static function get_xtra_product_data($service_id,$product_token)
    {

    $value=DB::table('addon_extra_services_product')->where('ex_service_id','=',$service_id)->where('ex_product_token','=',$product_token)->first(); 
    return $value;
	
    }
	
	public static function xtra_product_data($product_token)
   {

    $value=DB::table('addon_extra_services_product')->where('ex_product_token','=',$product_token)->orderBy('ex_product_id', 'asc')->get(); 
    return $value;
	
   }
   
   public static function get_xtra_category_data($service_id)
    {

    $value=DB::table('addon_extra_services_category')->where('ex_service_id','=',$service_id)->first(); 
    return $value;
	
    }
		
	
}
