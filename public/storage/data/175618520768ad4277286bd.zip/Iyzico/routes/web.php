<?php

use Illuminate\Support\Facades\Route;
use Modules\Iyzico\Http\Controllers\IyzicoController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('iyzicos', IyzicoController::class)->names('iyzico');
});
