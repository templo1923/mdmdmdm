<span class="ml-3">
<a href="javascript:void(0)" class="btn btn-primary btn-sm defaultbtn" id="fetchData">Ai Writer</a> <span id="loader" style="display: none;"><img src="{{ url('/') }}/Modules/AiWriter/resources/views/img/loading.gif" alt="Loading..." width="30" height="30" /></span>
</span>
<script type="text/javascript">
$(document).ready(function() {
'use strict';
        $('#fetchData').on('click', function() {
		    $("#loader").show();
            var inputValue = $('#textboxdata').val();
			if(inputValue == "")
			{
			 var tagname = $("#tagname");
			 var labelText = tagname.text(); 
			 var finaltext = labelText.replace("*", "");
			 alert("Please Fill Your "+ finaltext);
			}
            $.ajax({
                url: "{{ route('admin.fetch-data') }}", // Your Laravel route
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}', // CSRF token for Laravel
                    id: inputValue
                },
                success: function(response) {
				    $("#loader").hide();
                    // Handle the successful response from Laravel
                    //$('#summary-ckeditor').text(response.data); 
					
					tinymce.get('summary-ckeditor').setContent(response.data);
					
                },
                error: function(xhr, status, error) {
                    $("#loader").hide();
					console.error("AJAX Error: " + status + error);
                }
            });
        });
    });
</script>