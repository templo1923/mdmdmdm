<?php

use Illuminate\Support\Facades\Route;
use Modules\IDrive\Http\Controllers\IDriveController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('idrives', IDriveController::class)->names('idrive');
});
