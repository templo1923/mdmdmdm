<x-extraservices::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('extraservices.name') !!}</p>
</x-extraservices::layouts.master>
