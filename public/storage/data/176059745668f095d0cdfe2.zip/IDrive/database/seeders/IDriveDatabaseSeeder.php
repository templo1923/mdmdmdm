<?php

namespace Modules\IDrive\Database\Seeders;

use Illuminate\Database\Seeder;

class IDriveDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
