<?php

namespace Modules\Iyzico\Http\Controllers;


use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Iyzico\Models\Iyzico;
use Illuminate\Support\Facades\Validator;

class IyzicoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function iyzico_settings()
    {
	    $iyzico_setting = Iyzico::iyzico_Settings();
        return view('iyzico::iyzico-settings', [ 'iyzico_setting' => $iyzico_setting]);
    }
	
	
	
	public function update_iyzico_settings(Request $request)
	{
	   
	   
	   
	   $iyzico_status = $request->input('iyzico_status');
	   $iyzico_currency = $request->input('iyzico_currency');
	   $iyzico_mode = $request->input('iyzico_mode');
	   $iyzico_test_api_key = $request->input('iyzico_test_api_key');
	   $iyzico_test_secret_key = $request->input('iyzico_test_secret_key');
	   $iyzico_live_api_key = $request->input('iyzico_live_api_key');
	   $iyzico_live_secret_key = $request->input('iyzico_live_secret_key');
	   
	   
	   
	   $request->validate([
							
		]);
		$rules = array(
		);
		 
		$messsages = array(
		      
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('iyzico_status' => $iyzico_status, 'iyzico_currency' => $iyzico_currency, 'iyzico_mode' => $iyzico_mode, 'iyzico_test_api_key' => $iyzico_test_api_key, 'iyzico_test_secret_key' => $iyzico_test_secret_key, 'iyzico_live_api_key' => $iyzico_live_api_key, 'iyzico_live_secret_key' => $iyzico_live_secret_key);
		  Iyzico::updateIyzicoSettings($data);
		  return redirect()->back()->with('success','Updated successfully');
		  
		 
          
		  
		}
	
	}


    
}
