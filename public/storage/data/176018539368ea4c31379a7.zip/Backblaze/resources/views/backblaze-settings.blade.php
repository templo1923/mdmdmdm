<div class="col-md-12"><h5>{{ __('Backblaze Storage Configuration (If Backblaze B2 storage selected)') }}</h5></div>
                             <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                       
                                        <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('BACKBLAZE ACCESS KEY ID') }}</label>
                                                <input id="backblaze_access_key_id" name="backblaze_access_key_id" type="text" class="form-control noscroll_textarea" value="{{ $backblaze_setting->backblaze_access_key_id }}">
                                            </div>
                                        
                                         <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('BACKBLAZE SECRET ACCESS KEY') }}</label>
                                                <input id="backblaze_secret_access_key" name="backblaze_secret_access_key" type="text" class="form-control noscroll_textarea" value="{{ $backblaze_setting->backblaze_secret_access_key }}"> 
                                            </div>
                                           
                                    </div>
                                </div>

                            </div>
                            </div>
                            
                            <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                       
                                        <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('BACKBLAZE BUCKET ID') }}</label>
                                                <input id="backblaze_bucket_id" name="backblaze_bucket_id" type="text" class="form-control noscroll_textarea" value="{{ $backblaze_setting->backblaze_bucket_id }}">
                                                <small>Example : yourbucketid</small>
                                            </div>
                                        
                                         <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('BACKBLAZE BUCKET NAME') }}</label>
                                                <input id="backblaze_bucket_name" name="backblaze_bucket_name" type="text" class="form-control noscroll_textarea" value="{{ $backblaze_setting->backblaze_bucket_name }}"> <small>Example : yourbucketname</small>
                                            
                                            </div>
                                           
                                    </div>
                                </div>

                            </div>
                            </div>