<?php

namespace Modules\Iyzico\Database\Seeders;

use Illuminate\Database\Seeder;

class IyzicoDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
