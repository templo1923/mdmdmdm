<?php

return [
    'name' => 'Iyzico',
	'module_slug' => 'iyzico',
	'module_name' => 'Iyzico Payment Gateway for Downgrade',
	'module_version' => 'v1.0',
	'module_image' => 'iyzico.jpg',
];
