@if($xtra_setting->extra_service_status == 1)
<div class="col-md-12 mb-3"><div class="card-body"><h4>{{ __('Extra Services Fee Details') }}</h4></div></div>
@foreach($xtra_category as $xtra)
<div class="col-md-6">
   <div class="card-body extra-body">
        <!-- Credit Card -->
        <div id="pay-invoice">
            <div class="form-group">
                    <label for="site_title" class="control-label mb-1">{{ $xtra->ex_service_name }} ({{ $allsettings->site_currency_symbol }})</label><br/>
                         <input id="product_extra_fee" name="product_extra_fee[]" type="text" class="form-control noscroll_textarea" value="{{ Helper::get_product_data($xtra->ex_service_id,$product_token,'ex_service_fee') }}" data-bvalidator="number,min[0.1]">
                    </div>
                    <input type="hidden" name="service_id[]" value="{{ $xtra->ex_service_id }}">
           </div>
         </div>
        </div>
@endforeach
@endif