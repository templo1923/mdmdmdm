<?php

namespace Modules\AiWriter\Http\Controllers;

use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Gemini\Laravel\Facades\Gemini;
use DownGrade\Models\Addons;

class AiWriterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
	    $addonsetting = Addons::singleAddonsettings();
		$aiwriter_display_pages	 = explode(',', $addonsetting->aiwriter_display_pages	);
		$display_pages = array('add-product' => 'Add Product', 'edit-product' => 'Edit Product', 'add-post' => 'Add Post', 'edit-post' => 'Edit Post', 'add-page' => 'Add Page', 'edit-page' => 'Edit Page');
        return view('aiwriter::index', [ 'display_pages' => $display_pages, 'aiwriter_display_pages' => $aiwriter_display_pages]);
    }
	
	public function fetchData(Request $request)
        {
            $id = $request->input('id');
            if(!empty($id))
			{
            $result = Gemini::generativeModel(model: 'gemini-2.0-flash')->generateContent($id);

            $data =  $result->text();
			}
			else
			{
			$data = ""; 
			}
            //$data = DB::table('your_table_name')->where('id', $id)->value('another_column'); 

            if ($data) {
                return response()->json(['data' => $data]);
            } else {
                return response()->json(['data' => 'No data found'], 404);
            }
        }
	
	public function get_aicontent(Request $request)
	{
	   
	   /*$keyword = $request->input('keyword');*/
	   
	   $gemini_api_key = $request->input('gemini_api_key');
	   if(!empty($request->input('aiwriter_display_pages')))
	   {
	     $pages = "";
		 foreach($request->input('aiwriter_display_pages') as $keyvalue)
		 {
		    $pages .= $keyvalue.',';
		 }
		 $aiwriter_display_pages = rtrim($pages,',');
	   }
	   else
	   {
	   $aiwriter_display_pages = "";
	   }
	   
	   $request->validate([
							
		]);
		$rules = array(
		);
		 
		$messsages = array(
		      
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('gemini_api_key' => $gemini_api_key, 'aiwriter_display_pages' => $aiwriter_display_pages);
		  Addons::updateAddonSettings($data);
		  return redirect()->back()->with('success','Updated successfully');
		  /*$result = Gemini::generativeModel(model: 'gemini-2.0-flash')->generateContent($keyword);

          $datatext =  $result->text(); 
		  return view('aiwriter::index', [ 'datatext' => $datatext]);*/
		 
          
		  
		}
	
	}

    
    
}
