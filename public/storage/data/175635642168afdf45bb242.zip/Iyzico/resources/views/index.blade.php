<x-iyzico::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('iyzico.name') !!}</p>
</x-iyzico::layouts.master>
