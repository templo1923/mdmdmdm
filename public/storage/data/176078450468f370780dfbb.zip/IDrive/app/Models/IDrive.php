<?php

namespace Modules\IDrive\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class IDrive extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    public static function idrive_Settings()
    {

    $value=DB::table('addon_idrive_settings')->where('idr_id','=',1)->first(); 
    return $value;
	
    }
	
	public static function update_idrive_Settings($data)
	{
    DB::table('addon_idrive_settings')
      ->where('idr_id', 1)
      ->update($data);
    }
	
	
		
	
}
