<?php

use Illuminate\Support\Facades\Route;
use Modules\ExtraServices\Http\Controllers\ExtraServicesController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('extraservices', ExtraServicesController::class)->names('extraservices');
});
