-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 09:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `downgrade`
--

-- --------------------------------------------------------

--
-- Table structure for table `addon_extra_services_product`
--

CREATE TABLE `addon_extra_services_product` (
  `ex_product_id` int(11) NOT NULL,
  `ex_service_id` int(11) NOT NULL,
  `ex_product_token` varchar(191) DEFAULT NULL,
  `ex_service_fee` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addon_extra_services_product`
--

INSERT INTO `addon_extra_services_product` (`ex_product_id`, `ex_service_id`, `ex_product_token`, `ex_service_fee`) VALUES
(1, 5, 'SfMshw6UsNnZCqi2FsJCkP2Ql', 79),
(2, 6, 'SfMshw6UsNnZCqi2FsJCkP2Ql', 15),
(3, 7, 'SfMshw6UsNnZCqi2FsJCkP2Ql', 14),
(4, 5, 'HkUZphbtZGjckUp2l35syHJ9f', 65),
(5, 6, 'HkUZphbtZGjckUp2l35syHJ9f', 25),
(6, 7, 'HkUZphbtZGjckUp2l35syHJ9f', 14.5),
(7, 5, 'sDnVKtQMlrfsQ6HUIrEfPQNhr', 98),
(8, 6, 'sDnVKtQMlrfsQ6HUIrEfPQNhr', 67),
(9, 7, 'sDnVKtQMlrfsQ6HUIrEfPQNhr', 33),
(10, 5, 'TZ9BhX9EaEKC4d3Guhr4WkHl9', 40),
(11, 6, 'TZ9BhX9EaEKC4d3Guhr4WkHl9', 70),
(12, 7, 'TZ9BhX9EaEKC4d3Guhr4WkHl9', 100),
(13, 5, 'AMqcrMlfKso08tHpxrYFdi5PV', 47),
(14, 6, 'AMqcrMlfKso08tHpxrYFdi5PV', 11),
(15, 7, 'AMqcrMlfKso08tHpxrYFdi5PV', 13),
(16, 5, 'Bi41VdRAKMuvR8F5sA5xHvv1a', 140),
(17, 6, 'Bi41VdRAKMuvR8F5sA5xHvv1a', 19),
(18, 7, 'Bi41VdRAKMuvR8F5sA5xHvv1a', 78),
(19, 5, 'si39CjKgJYSv3nrLvkUoJObkM', 73),
(20, 6, 'si39CjKgJYSv3nrLvkUoJObkM', 148),
(21, 7, 'si39CjKgJYSv3nrLvkUoJObkM', 79),
(22, 5, 'fdIgZfiZKARZaAXCJg84hNVBf', 9),
(23, 6, 'fdIgZfiZKARZaAXCJg84hNVBf', 49),
(24, 7, 'fdIgZfiZKARZaAXCJg84hNVBf', 19),
(25, 5, 'yqB5h8CYCRlALTAWPRxhtKbac', 36),
(26, 6, 'yqB5h8CYCRlALTAWPRxhtKbac', 46),
(27, 7, 'yqB5h8CYCRlALTAWPRxhtKbac', 86),
(28, 5, '9k8VnbmpbLdoP7qFvP5cUm9KO', 11),
(29, 6, '9k8VnbmpbLdoP7qFvP5cUm9KO', 31),
(30, 7, '9k8VnbmpbLdoP7qFvP5cUm9KO', 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addon_extra_services_product`
--
ALTER TABLE `addon_extra_services_product`
  ADD PRIMARY KEY (`ex_product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addon_extra_services_product`
--
ALTER TABLE `addon_extra_services_product`
  MODIFY `ex_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
