<?php

namespace Modules\Storj\Database\Seeders;

use Illuminate\Database\Seeder;

class StorjDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
