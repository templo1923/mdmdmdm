<?php

use Illuminate\Support\Facades\Route;
use Modules\ExtraServices\Http\Controllers\ExtraServicesController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('extraservices', ExtraServicesController::class)->names('extraservices');
});
