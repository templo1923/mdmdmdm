-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2025 at 02:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `downgrade`
--

-- --------------------------------------------------------

--
-- Table structure for table `addon_backblaze_settings`
--

CREATE TABLE `addon_backblaze_settings` (
  `bb_id` int(11) NOT NULL,
  `backblaze_access_key_id` varchar(191) DEFAULT NULL,
  `backblaze_secret_access_key` varchar(191) DEFAULT NULL,
  `backblaze_bucket_name` varchar(50) DEFAULT NULL,
  `backblaze_bucket_id` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addon_backblaze_settings`
--

INSERT INTO `addon_backblaze_settings` (`bb_id`, `backblaze_access_key_id`, `backblaze_secret_access_key`, `backblaze_bucket_name`, `backblaze_bucket_id`) VALUES
(1, 'dsfdsafdsafsafsafdsfasfdsfdsa', 'dsfdsafdsafsafsafdsfasfdsfdsa', 'downgrade', 'dsfdsafdsafsafsafdsfasfdsfdsa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addon_backblaze_settings`
--
ALTER TABLE `addon_backblaze_settings`
  ADD PRIMARY KEY (`bb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addon_backblaze_settings`
--
ALTER TABLE `addon_backblaze_settings`
  MODIFY `bb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
