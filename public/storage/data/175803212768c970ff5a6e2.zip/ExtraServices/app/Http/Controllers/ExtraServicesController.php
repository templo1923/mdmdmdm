<?php

namespace Modules\ExtraServices\Http\Controllers;

use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\ExtraServices\Models\Extra;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;

class ExtraServicesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function extra_services()
	{
	    $xtra_category = Extra::xtra_Category();
	    return view('extraservices::extra-services', [ 'xtra_category' => $xtra_category]);
	  
	} 
	
	public function update_extra_services(Request $request)
	{
	   
	   
	   
	   $extra_service_status = $request->input('extra_service_status');
	   
	   
	   
	   
	   $request->validate([
							
		]);
		$rules = array(
		);
		 
		$messsages = array(
		      
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('extra_service_status' => $extra_service_status);
		  Extra::update_extra_Settings($data);
		  return redirect()->back()->with('success','Updated successfully');
		  
		 
          
		  
		}
	
	}
	
	public function add_extra_service()
	{
	    
	    return view('extraservices::add-extra-service');
	  
	} 
	
	
	public function save_extra_service(Request $request)
	{
	   
	   
	   
	   $ex_service_name = $request->input('ex_service_name');
	   $ex_service_order = $request->input('ex_service_order');
	   $ex_service_status = $request->input('ex_service_status');
	   
	   
	   $request->validate([
							
		]);
		$rules = array(
					
					'ex_service_name' => ['required', Rule::unique('addon_extra_services_category') -> where(function($sql){ $sql->where('ex_service_drop_status','=','no');})],
					
					
			 );
		 
		$messsages = array(
		      'ex_service_name.unique' => 'This service name is already exists.',
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('ex_service_name' => $ex_service_name, 'ex_service_order' => $ex_service_order, 'ex_service_status' => $ex_service_status);
		  Extra::save_xtra_Category($data);
		  return redirect('/admin/extra-services')->with('success', 'Insert successfully.');
		 
          
		  
		}
	
	}
	
	
	public function delete_extra_services($id)
	{
	    $encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
	    $token   = $encrypter->decrypt($id);
		$data = array("ex_service_drop_status" => "yes");
		Extra::delete_xtra_category($token,$data);
		return redirect('/admin/extra-services')->with('success','Delete successfully.');
	}
	
	public function edit_extra_services($id)
	{
	$encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
    $token   = $encrypter->decrypt($id);
	$edit = Extra::edit_xtra_category($token);
	return view('extraservices::edit-extra-service', [ 'edit' => $edit]);
	}
	
	
	
	public function up_extra_service(Request $request)
	{
	   
	   
	   
	   $ex_service_name = $request->input('ex_service_name');
	   $ex_service_order = $request->input('ex_service_order');
	   $ex_service_status = $request->input('ex_service_status');
	   $ex_service_id = $request->input('ex_service_id');
	   
	   $request->validate([
							
		]);
		$rules = array(
					
					
					'ex_service_name' => ['required', Rule::unique('addon_extra_services_category') ->ignore($ex_service_id, 'ex_service_id') -> where(function($sql){ $sql->where('ex_service_drop_status','=','no');})],
					
			 );
		 
		$messsages = array(
		      'ex_service_name.unique' => 'This service name is already exists.',
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('ex_service_name' => $ex_service_name, 'ex_service_order' => $ex_service_order, 'ex_service_status' => $ex_service_status);
		  Extra::update_xtra_category($ex_service_id,$data);
		  return redirect('/admin/extra-services')->with('success', 'Update successfully.');
		 
          
		  
		}
	
	}
	
	
	public function all_delete_extra_services(Request $request)
	{
	   
	   $ex_service_id = $request->input('ex_service_id');
	   $data = array('ex_service_drop_status' => 'yes');
	   foreach($ex_service_id as $id)
	   {
	      
		  Extra::delete_xtra_category($id,$data);
	   }
	   return redirect()->back()->with('success','Delete successfully.');
	
	}
	
    public function saveExtrafee($product_extra_fee,$service_id,$product_token)
	{
	    Extra::delete_xtra_Product($product_token);
		foreach ($service_id as $index => $value) 
		{
		    $extra_fee = $product_extra_fee[$index];
			$service_key = $value;
			$data = array('ex_service_id' => $service_key, 'ex_product_token' => $product_token, 'ex_service_fee' => $extra_fee);
			if(!empty($extra_fee))
			{
			Extra::save_xtra_Product($data);		  
			}
		}
		
	} 
	public function deleteExtrafee($product_token)
	{
	  
	  Extra::delete_xtra_Product($product_token);  
	}
    
}
