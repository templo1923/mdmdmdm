<?php

use Illuminate\Support\Facades\Route;
use Modules\AiWriter\Http\Controllers\AiWriterController;

/*Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('aiwriters', AiWriterController::class)->names('aiwriter');
});*/
Route::middleware(['is_admin', 'XSS', 'HtmlMinifier'])->group(function () {

Route::get('/admin/aiwriter', [AiWriterController::class, 'index']);
Route::post('/admin/aiwriter', [AiWriterController::class, 'get_aicontent'])->name('admin.aiwriter');
Route::post('/admin/fetch-data', [AiWriterController::class, 'fetchData'])->name('admin.fetch-data');

});