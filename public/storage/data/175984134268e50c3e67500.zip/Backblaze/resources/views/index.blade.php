<x-backblaze::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('backblaze.name') !!}</p>
</x-backblaze::layouts.master>
