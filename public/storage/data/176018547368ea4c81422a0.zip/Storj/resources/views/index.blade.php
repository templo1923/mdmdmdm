<x-storj::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('storj.name') !!}</p>
</x-storj::layouts.master>
