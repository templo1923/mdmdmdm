<?php

namespace Modules\IDrive\Http\Controllers;

use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\IDrive\Models\IDrive;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;
use Storage;

class IDriveController extends Controller
{
    
	
	public function uploadIdrive($img_name,$image)
	{
	    Storage::disk('e2')->put($img_name, file_get_contents($image), 'public');
	    
	}
	public function updateIdrive($idrive_access_key_id,$idrive_secret_access_key,$idrive_endpoint,$idrive_region,$idrive_bucket)
	{
	    $data = array('idrive_access_key_id' => $idrive_access_key_id, 'idrive_secret_access_key' => $idrive_secret_access_key, 'idrive_endpoint' => $idrive_endpoint, 'idrive_region' => $idrive_region, 'idrive_bucket' => $idrive_bucket);
	    IDrive::update_idrive_Settings($data);
	}
	
	public function downloadIdrive($drive_file_name,$extension)
	{
	     $myFile = Storage::disk('e2')->url($drive_file_name);
		 $newName = uniqid().time().'.'.$extension;
		 header("Cache-Control: public");
		 header("Content-Description: File Transfer");
		 header("Content-Disposition: attachment; filename=" . basename($newName));
		 header("Content-Type: application/octet-stream");
		 return readfile($myFile);
	}
	public function deleteIdrive($drive_file_name)
	{
	  Storage::disk('e2')->delete($drive_file_name);
    }
    
}
