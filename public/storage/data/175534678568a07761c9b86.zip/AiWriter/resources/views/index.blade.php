<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]--><head>
    
    @include('admin.stylesheet')
    

<link rel="stylesheet" type="text/css" href="{{ URL::to('Modules/AiWriter/resources/views/theme/style.css')}}">
</head>

<body>
    
    @include('admin.navigation')

    <!-- Right Panel -->
    @if(in_array('maintenance',$avilable))
    <div id="right-panel" class="right-panel">

       
                       @include('admin.header')
                       

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>{{ __('Ai Writer') }} <br/><code class="version_text">{{ $addon_version }}</code></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    
                </div>
            </div>
        </div>
        
        @include('admin.warning')

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                       
                        <div class="card">
                           @if($demo_mode == 'on')
                           @include('admin.demo-mode')
                           @else
                           <form action="{{ route('admin.aiwriter') }}" method="post" id="setting_form" enctype="multipart/form-data">
                           {{ csrf_field() }}
                           @endif
                           <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                        
                                         
                                            
                                            
                                            <div class="form-group"> 
                                              <h5>Setup your API key</h5><br/>
                                            <p>Create a key in Google AI Studio, Click this link : <code><a href="https://aistudio.google.com/app/apikey" target="_blank" class="pink-color">https://aistudio.google.com/app/apikey</a></code></p>
                                            <p><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal_three" class="blue-color">How to Get an API key?</a></p> 
                                            </div> 
                                            
                                            
                                              
                                        
                                    </div>
                                </div>

                            </div>
                            </div>
                            
                            
                            
                             <div class="col-md-6">
                             
                             
                             <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                             
                             <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('Gemini API Key') }} <span class="require">*</span></label>
                                                <input id="gemini_api_key" name="gemini_api_key" type="text" class="form-control noscroll_textarea" data-bvalidator="required" value="{{ $addon_settings->gemini_api_key }}">
                                                
                                            </div>
                                           
                             
                             </div>
                                </div>

                            </div>
                             
                             
                             
                             </div>
                             <div class="col-md-12">&nbsp;</div>
                             
                             <div class="col-md-6">
                           
                             <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                           
                                            <div class="form-group">
                                                <h5>{{ __('Display Pages') }}</h5><br/>
                                                <label for="site_title" class="control-label mb-1"><strong>{{ __('Pages') }}</strong> </label><br/>
                                                @foreach($display_pages as $key => $value)
                                                <input id="aiwriter_display_pages" name="aiwriter_display_pages[]" type="checkbox" class="noscroll_textarea" value="{{ $key }}" @if(in_array($key,$aiwriter_display_pages)) checked @endif> {{ $value }}<br/>
                                                @endforeach
                                            </div>  
                                            
                                            
                                            
                                        
                                    </div>
                                </div>

                            </div>
                            </div>
                             
                             
                             
                             <div class="col-md-12 no-padding">
                             <div class="card-footer">
                                                        <button type="submit" name="submit" class="btn btn-primary btn-sm">
                                                            <i class="fa fa-dot-circle-o"></i> {{ __('Submit') }}
                                                        </button>
                                                        <button type="reset" class="btn btn-danger btn-sm">
                                                            <i class="fa fa-ban"></i> {{ __('Reset') }}
                                                        </button>
                                                    </div>
                             
                             </div>
                             
                            
                            </form>
                            
                                                    
                                                    
                                                 
                            
                        </div> 

                     
                    
                    
                    </div>
                    

                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->
    @else
    @include('admin.denied')
    @endif
    <!-- Right Panel -->


   @include('admin.javascript')

<div id="myModal_three" class="modal fade 2checkout" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body">
            <img class="lazy" width="1223" height="678" src="{{ url('/') }}/Modules/AiWriter/resources/views/img/gemini_api_key.png"  class="img-responsive">
        </div>
    </div>
  </div>
</div>
</body>

</html>
