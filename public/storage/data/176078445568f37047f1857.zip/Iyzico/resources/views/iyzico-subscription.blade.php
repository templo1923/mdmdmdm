@if($iyzico_setting->iyzico_status == 1)
<div class="card-header" role="tab"> 
      <h3 class="accordion-heading"><a href="#iyzico" id="iyzico" data-toggle="collapse">{{ __('Pay with Iyzico') }}<span class="accordion-indicator"><i data-feather="chevron-up"></i></span></a></h3> 
</div> 
<div class="collapse " id="iyzico" data-parent="#payment-method" role="tabpanel"> 
   <div class="card-body font-size-sm custom-control custom-radio"> <p><span class="font-weight-medium">
      <input id="opt1-iyzico" name="payment_method" type="radio" class="custom_radio" value="iyzico" data-bvalidator="required"> {{ __('Iyzico') }}</span></p> <button class="btn btn-primary" type="submit">{{ __('Pay with Iyzico') }}</button> 
   </div> 
</div>
@endif 
               