@if($xtra_setting->extra_service_status == 1)
<div class="mt-3">
@if(!empty($cart->extra_service_ids))
<h6 class="mt-4"><strong>{{ __('Extra Services') }}</strong></h6>
@php
$commaSeparatedString = $cart->extra_service_ids;
$valuesArray = explode(",", $commaSeparatedString);
$xtra_fee = explode(",", $cart->extra_service_fees);
@endphp
@foreach ($valuesArray as $index => $value) 
<p class="product-title xtrafee-lineheight"><a href="{{ url('/item') }}/{{ $cart->product_slug }}">{{ ModuleHelper::get_category_data($value,'ex_service_name') }} - {{ $allsettings->site_currency_symbol }} {{ $xtra_fee[$index] }}</a></p>
@endforeach
@endif
</div>
@endif