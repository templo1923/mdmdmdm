<?php

return [
    'name' => 'AiWriter',
];
