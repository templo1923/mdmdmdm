<?php

use Modules\ExtraServices\Models\Extra;



class ModuleHelper 
{



    
	public static function get_product_data($service_id,$product_token,$column)
	{
	   
	   $data = Extra::get_xtra_product_data($service_id,$product_token);
	   if(!empty($data->$column))
	   {
	   return $data->$column;
	   }
	   else
	   {
	   return "";   
	   }
	   
	}
	
	
	public static function get_category_data($service_id,$column)
	{
	   
	   $data = Extra::get_xtra_category_data($service_id);
	   if(!empty($data->$column))
	   {
	   return $data->$column;
	   }
	   else
	   {
	   return "";   
	   }
	   
	}
	
}	