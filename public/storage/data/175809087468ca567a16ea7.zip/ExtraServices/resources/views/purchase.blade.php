@if($xtra_setting->extra_service_status == 1)
@if(!empty($item->extra_service_ids))
<div class="mt-3 ml-4 alert alert-success">
<h6 class="mt-2"><strong>{{ __('Extra Services') }}</strong></h6>
@php
$commaSeparatedString = $item->extra_service_ids;
$valuesArray = explode(",", $commaSeparatedString);
$xtra_fee = explode(",", $item->extra_service_fees);
@endphp
@foreach ($valuesArray as $index => $value) 
<p class="product-title xtrafee-lineheight"><a href="{{ url('/item') }}/{{ $item->product_slug }}">{{ Helper::get_category_data($value,'ex_service_name') }} - {{ $allsettings->site_currency_symbol }} {{ $xtra_fee[$index] }}</a></p>
@endforeach
</div>
@endif
@endif