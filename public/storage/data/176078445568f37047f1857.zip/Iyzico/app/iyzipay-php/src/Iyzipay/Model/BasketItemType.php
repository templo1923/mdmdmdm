<?php

namespace Iyzipay\Model;

class BasketItemType
{
    const PHYSICAL = "PHYSICAL";
    const VIRTUAL = "VIRTUAL";
}