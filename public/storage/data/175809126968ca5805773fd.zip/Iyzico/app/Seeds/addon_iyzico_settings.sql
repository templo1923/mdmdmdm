-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2025 at 06:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `downgrade`
--

-- --------------------------------------------------------

--
-- Table structure for table `addon_iyzico_settings`
--

CREATE TABLE `addon_iyzico_settings` (
  `iyzico_id` int(11) NOT NULL,
  `iyzico_status` int(10) NOT NULL,
  `iyzico_mode` int(10) NOT NULL,
  `iyzico_currency` varchar(20) NOT NULL DEFAULT 'TRY',
  `iyzico_test_api_key` varchar(191) DEFAULT NULL,
  `iyzico_test_secret_key` varchar(191) DEFAULT NULL,
  `iyzico_live_api_key` varchar(191) DEFAULT NULL,
  `iyzico_live_secret_key` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addon_iyzico_settings`
--

INSERT INTO `addon_iyzico_settings` (`iyzico_id`, `iyzico_status`, `iyzico_mode`, `iyzico_currency`, `iyzico_test_api_key`, `iyzico_test_secret_key`, `iyzico_live_api_key`, `iyzico_live_secret_key`) VALUES
(1, 1, 0, 'TRY', 'sandbox-XzFhaxFfOV51Gj8tHK3uoELmUuU2p8B6', 'VIEq8sDPoDJRyyLT3vlQjp6sIlMB6PDL', 'live- k2uznqeto7jgdyh5c5k03cn141d872', 'live-8pqee0203rsu0ewo14d8a4vwsjaprq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addon_iyzico_settings`
--
ALTER TABLE `addon_iyzico_settings`
  ADD PRIMARY KEY (`iyzico_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addon_iyzico_settings`
--
ALTER TABLE `addon_iyzico_settings`
  MODIFY `iyzico_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
