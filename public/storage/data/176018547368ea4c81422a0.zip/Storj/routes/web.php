<?php

use Illuminate\Support\Facades\Route;
use Modules\Storj\Http\Controllers\StorjController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('storjs', StorjController::class)->names('storj');
});
