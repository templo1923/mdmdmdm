<?php

namespace Modules\Iyzico\Http\Controllers;


use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Iyzico\Models\Iyzico;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use DownGrade\Models\Product;
use DownGrade\Models\Members;
use DownGrade\Models\Settings;
use DownGrade\Models\EmailTemplate;
use DownGrade\Models\Subscription;
use Mail;
use Currency;
use URL;
use Auth;
use IyzipayBootstrap;
use GuzzleHttp\Client;


class IyzicoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
	
	 
	public function iyzicoSubscription($user_subscr_type,$price,$site_currency,$purchase_token,$user_id,$user_name,$order_email,$user_token)
	{
	        $encrypter = app('Illuminate\Contracts\Encryption\Encrypter'); 
	        $iyzico_setting = Iyzico::iyzico_Settings();
			$iyzico_mode = $iyzico_setting->iyzico_mode;
			if($iyzico_mode == 0)
			{
				$iyzico_url = 'https://sandbox-api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_test_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_test_secret_key;
			}
			else
			{
				$iyzico_url = 'https://api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_live_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_live_secret_key;
			}
			$website_url = URL::to('/');
			$iyzico_success_url = $website_url.'/iyzico-subscription/'.$encrypter->encrypt($purchase_token);
			if($site_currency != 'TRY')
			 {
			   $convert = Currency::convert($site_currency,'TRY',$price);
			   $price_amount = $convert['convertedAmount'];
			   
			 }
			 else
			 {
			   $price_amount = $price;
			 }
			 
		$endpoint = $website_url."/Modules/Iyzico/app/iyzipay-php/iyzico.php";
		   $client = new Client(['base_uri' => $endpoint]);
             $api_key = $iyzico_api_key;
			 $secret_key = $iyzico_secret_key;
			 $iyzi_url = $iyzico_url;
			 $purchased_token = $purchase_token;
			 $amount = $price_amount;
			 $userids = $user_id;
			 $usernamer = $user_name;
             $response = $client->request('GET', $endpoint, ['query' => [
				'iyzico_api_key' => $api_key, 
				'iyzico_secret_key' => $secret_key,
				'iyzico_url' => $iyzi_url,
				'purchase_token' => $purchased_token,
				'price_amount' => $amount,
				'user_id' => $userids,
				'username' => $usernamer,
				'email' => $order_email,
				'user_token' => $user_token,
				'item_name' => $user_subscr_type,
				'iyzico_success_url' => $iyzico_success_url,
				
			]]);
        
            echo $response->getBody();	 
	
	
	
	} 
	
	
	public function iyzico_subscription($ord_token, Request $request)
	{
	
	  $encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
	  $purchase_token = $encrypter->decrypt($ord_token);
	  include(base_path() . '/Modules/Iyzico/app/iyzipay-php/IyzipayBootstrap.php');
	  IyzipayBootstrap::init();
	  $options = new \Iyzipay\Options();
	  $iyzico_setting = Iyzico::iyzico_Settings();
	  $iyzico_mode = $iyzico_setting->iyzico_mode;
	  if($iyzico_mode == 0)
	  {
				$iyzico_url = 'https://sandbox-api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_test_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_test_secret_key;
	  }
	  else
	  {
				$iyzico_url = 'https://api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_live_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_live_secret_key;
	  }
	  $options->setApiKey($iyzico_api_key);
	  $options->setSecretKey($iyzico_secret_key);
	  $options->setBaseUrl($iyzico_url);
	  
	  # create request class
	  $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
	  $request->setLocale(\Iyzipay\Model\Locale::TR);
	  $request->setConversationId($purchase_token);
	  $request->setToken($_REQUEST['token']);
      # make request
      $checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
      # print result
      //echo $checkoutForm->getPaymentStatus();
      //echo $checkoutForm->getPaymentId();
	  $payment_token = $checkoutForm->getPaymentId();
	  $payment_status = 'completed';
	  $purchased_token = $purchase_token;
	  $iyzico_status = $checkoutForm->getPaymentStatus();
	  if($iyzico_status == 'SUCCESS')
	  {
						
				$subscr_id = Auth::user()->user_subscr_id;
				$subscr['view'] = Subscription::editsubData($subscr_id);
				$subscri_date = $subscr['view']->subscr_duration;
				$user_subscr_item_level = $subscr['view']->subscr_item_level;
				$user_subscr_item = $subscr['view']->subscr_item;
				$user_subscr_type = $subscr['view']->subscr_name;
				$subscr_value = "+".$subscri_date;
				$subscr_date = date('Y-m-d', strtotime($subscr_value));
				$user_id = Auth::user()->id;
				$payment_status = 'completed';
				
				$checkoutdata = array('user_subscr_type' => $user_subscr_type, 'user_subscr_date' => $subscr_date, 'user_subscr_item_level' => $user_subscr_item_level, 'user_subscr_item' => $user_subscr_item, 'user_subscr_payment_status' => $payment_status);
				Subscription::confirmsubscriData($user_id,$checkoutdata);
				/* subscription email */
				$sid = 1;
				$setting['setting'] = Settings::editGeneral($sid);
				$currency = $setting['setting']->site_currency_code;
				$subscr_price = $subscr['view']->subscr_price;
				$admin_name = $setting['setting']->sender_name;
				$admin_email = $setting['setting']->sender_email;
				$buyer_name = Auth::user()->name;
				$buyer_email = Auth::user()->email;
				$buyer_data = array('user_subscr_type' => $user_subscr_type, 'subscr_date' => $subscr_date, 'subscri_date' =>  $subscri_date, 'subscr_price' => $subscr_price, 'currency' => $currency); 
				/* email template code */
								$checktemp = EmailTemplate::checkTemplate(20);
								if($checktemp != 0)
								{
									$template_view['mind'] = EmailTemplate::viewTemplate(20);
									$template_subject = $template_view['mind']->et_subject;
								}
								else
								{
									$template_subject = "Subscription Upgrade";
								}
								/* email template code */
				Mail::send('subscription_mail', $buyer_data , function($message) use ($admin_name, $admin_email, $buyer_name, $buyer_email, $template_subject) {
					$message->to($buyer_email, $buyer_name)
					->subject($template_subject);
					$message->from($admin_email,$admin_name);
				});
				/* subscription email */
				$result_data = array('payment_token' => $payment_token);
				return view('success')->with($result_data);
	
			
	
	  }
	  else
	  {
			   return view('cancel');
	  }	
		
   }
	 
	 
	public function iyzicoMethod($item_names_data,$final_amount,$site_currency,$purchase_token,$user_id,$order_firstname,$order_email,$user_key_token)
	{
	        $encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
	        $iyzico_setting = Iyzico::iyzico_Settings();
			$iyzico_mode = $iyzico_setting->iyzico_mode;
			if($iyzico_mode == 0)
			{
				$iyzico_url = 'https://sandbox-api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_test_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_test_secret_key;
			}
			else
			{
				$iyzico_url = 'https://api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_live_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_live_secret_key;
			}
			$website_url = URL::to('/');
			$iyzico_success_url = $website_url.'/iyzico-success/'.$encrypter->encrypt($purchase_token);
			if($site_currency != 'TRY')
			 {
			   $convert = Currency::convert($site_currency,'TRY',$final_amount);
			   $price_amount = $convert['convertedAmount'];
			   
			 }
			 else
			 {
			   $price_amount = $final_amount;
			 }
			 
		$endpoint = $website_url."/Modules/Iyzico/app/iyzipay-php/iyzico.php";
		   $client = new Client(['base_uri' => $endpoint]);
             $api_key = $iyzico_api_key;
			 $secret_key = $iyzico_secret_key;
			 $iyzi_url = $iyzico_url;
			 $purchased_token = $purchase_token;
			 $amount = $price_amount;
			 $userids = $user_id;
			 $usernamer = $order_firstname;
             $response = $client->request('GET', $endpoint, ['query' => [
				'iyzico_api_key' => $api_key, 
				'iyzico_secret_key' => $secret_key,
				'iyzico_url' => $iyzi_url,
				'purchase_token' => $purchased_token,
				'price_amount' => $amount,
				'user_id' => $userids,
				'username' => $usernamer,
				'email' => $order_email,
				'user_token' => $user_key_token,
				'item_name' => $item_names_data,
				'iyzico_success_url' => $iyzico_success_url,
				
			]]);
        
            echo $response->getBody();	 
			 
	   
	   
	} 
	
		
	
	public function iyzico_success($ord_token, Request $request)
	{
	 
	  $encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
	  $purchase_token = $encrypter->decrypt($ord_token);
	  include(base_path() . '/Modules/Iyzico/app/iyzipay-php/IyzipayBootstrap.php');
	  IyzipayBootstrap::init();
	  $options = new \Iyzipay\Options();
	  $iyzico_setting = Iyzico::iyzico_Settings();
	  $iyzico_mode = $iyzico_setting->iyzico_mode;
	  if($iyzico_mode == 0)
	  {
				$iyzico_url = 'https://sandbox-api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_test_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_test_secret_key;
	  }
	  else
	  {
				$iyzico_url = 'https://api.iyzipay.com';
				$iyzico_api_key = $iyzico_setting->iyzico_live_api_key;
			    $iyzico_secret_key = $iyzico_setting->iyzico_live_secret_key;
	  }
	  $options->setApiKey($iyzico_api_key);
	  $options->setSecretKey($iyzico_secret_key);
	  $options->setBaseUrl($iyzico_url);
	  
	  # create request class
	  $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
	  $request->setLocale(\Iyzipay\Model\Locale::TR);
	  $request->setConversationId($purchase_token);
	  $request->setToken($_REQUEST['token']);
      # make request
      $checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
      # print result
      //echo $checkoutForm->getPaymentStatus();
      //echo $checkoutForm->getPaymentId();
	  $payment_token = $checkoutForm->getPaymentId();
	  $payment_status = 'completed';
	  $purchased_token = $purchase_token;
	  $iyzico_status = $checkoutForm->getPaymentStatus();
	  if($iyzico_status == 'SUCCESS')
	  {
						
				$custom_settings = Settings::editCustom();		
				$orderdata = array('payment_token' => $payment_token, 'order_status' => $payment_status);
				$checkoutdata = array('payment_token' => $payment_token, 'payment_status' => $payment_status);
				Product::singleordupdateData($purchased_token,$orderdata);
				Product::singlecheckoutData($purchased_token,$checkoutdata);
				
				$token = $purchased_token;
				$check['display'] = Product::getcheckoutData($token);
				$order_id = $check['display']->order_ids;
				$order_loop = explode(',',$order_id);
				
				/* download file */
				$download_file = "";
				/* download file */
				foreach($order_loop as $order)
				{
									
					$getitem['item'] = Product::getorderData($order);
					$token = $getitem['item']->product_token;
					$item['display'] = Product::solditemData($token);
					$product_sold = $item['display']->product_sold + 1;
					$item_token = $token; 
					$data = array('product_sold' => $product_sold);
					Product::updateitemData($item_token,$data);
					
					$orderdata = array('approval_status' => 'payment released to admin');
					Product::singleorderupData($order,$orderdata);
					/* download file */
					$encrypter = app('Illuminate\Contracts\Encryption\Encrypter');
					$download_file .= URL::to('/download-file').'/'.$encrypter->encrypt($item['display']->product_token).'<br/><br/>';
					/* download file */
					
				}
				
				$checkout['details'] = Product::getcheckoutData($purchased_token);
				$final_amount = $checkout['details']->total;
				$user_id = $checkout['details']->user_id;
				$admin['info'] = Members::adminData();
				$admin_token = $admin['info']->user_token;
				$admin_earning = $admin['info']->earnings + $final_amount;
				$admin_record = array('earnings' => $admin_earning);
				Members::updateadminData($admin_token, $admin_record);
				
								 
				$sid = 1;
				$setting['setting'] = Settings::editGeneral($sid);
				$to_name = $setting['setting']->sender_name;
				$to_email = $setting['setting']->sender_email;
				$currency = $setting['setting']->site_currency_code;
				$from['info'] = Members::singlevendorData($user_id);
				$from_name = $from['info']->name;
				$from_email = $from['info']->email;
				$data = array('to_name' => $to_name, 'to_email' => $to_email, 'final_amount' => $final_amount, 'currency' => $currency, 'from_name' => $from_name, 'from_email' => $from_email, 'purchased_token' => $purchased_token, 'download_file' => $download_file);
				/* email template code */
								$checktemp = EmailTemplate::checkTemplate(21);
								if($checktemp != 0)
								{
									$template_view['mind'] = EmailTemplate::viewTemplate(21);
									$template_subject = $template_view['mind']->et_subject;
								}
								else
								{
									$template_subject = "Item Purchase Notifications";
								}
								/* email template code */
								Mail::send('admin_payment_mail', $data , function($message) use ($from_name, $from_email, $to_name, $to_email, $purchased_token, $template_subject) {
										$message->to($to_email, $to_name)
												->subject($template_subject);
										$message->from($from_email,$from_name);
									});
								 
								if($purchased_token != "")
								{
								Mail::send('admin_payment_mail', $data , function($message) use ($from_name, $from_email, $to_name, $to_email, $purchased_token, $template_subject) {
										$message->to($from_email,$from_name)
												->subject($template_subject);
										$message->from($to_email, $to_name);
									});
								}
								 
				
				/* referral per sale earning */
					if($custom_settings->affiliate_referral == 1)
					{
						$logged_id = Auth::user()->id;
						$buyer_details = Members::singlebuyerData($logged_id);
						$referral_by = $buyer_details->referral_by;
						
						/* new code */
						if($custom_settings->per_sale_referral_commission_type == 'fixed')
						{
						$per_sale_commission = $setting['setting']->per_sale_referral_commission;
						}
						else
						{
						$per_sale_commission = ($setting['setting']->per_sale_referral_commission * $final_amount) / 100;
						}
						$referral_commission = $per_sale_commission;
						/* new code */
						$check_referral = Members::referralCheck($referral_by);
						  if($check_referral != 0)
						  {
							  $referred['display'] = Members::referralUser($referral_by);
							  $wallet_amount = $referred['display']->earnings + $referral_commission;
							  $referral_amount = $referred['display']->referral_amount + $referral_commission;
							  $update_data = array('earnings' => $wallet_amount, 'referral_amount' => $referral_amount);
							  Members::updateReferral($referral_by,$update_data);
						   } 
					}	   
				/* referral per sale earning */	
				$result_data = array('payment_token' => $payment_token);
				return view('success')->with($result_data);
			
	
	  }
	  else
	  {
			   return view('cancel');
	  }	
		
   }
	 
    public function iyzico_settings()
    {
	    $iyzico_setting = Iyzico::iyzico_Settings();
        return view('iyzico::iyzico-settings', [ 'iyzico_setting' => $iyzico_setting]);
    }
	
	
	
	public function update_iyzico_settings(Request $request)
	{
	   
	   
	   
	   $iyzico_status = $request->input('iyzico_status');
	   $iyzico_currency = $request->input('iyzico_currency');
	   $iyzico_mode = $request->input('iyzico_mode');
	   $iyzico_test_api_key = $request->input('iyzico_test_api_key');
	   $iyzico_test_secret_key = $request->input('iyzico_test_secret_key');
	   $iyzico_live_api_key = $request->input('iyzico_live_api_key');
	   $iyzico_live_secret_key = $request->input('iyzico_live_secret_key');
	   
	   
	   
	   $request->validate([
							
		]);
		$rules = array(
		);
		 
		$messsages = array(
		      
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $data = array('iyzico_status' => $iyzico_status, 'iyzico_currency' => $iyzico_currency, 'iyzico_mode' => $iyzico_mode, 'iyzico_test_api_key' => $iyzico_test_api_key, 'iyzico_test_secret_key' => $iyzico_test_secret_key, 'iyzico_live_api_key' => $iyzico_live_api_key, 'iyzico_live_secret_key' => $iyzico_live_secret_key);
		  Iyzico::updateIyzicoSettings($data);
		  return redirect()->back()->with('success','Updated successfully');
		  
		 
          
		  
		}
	
	}


    
}
