<?php

namespace Modules\AiWriter\Http\Controllers;

use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Gemini\Laravel\Facades\Gemini;

class AiWriterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
	    $datatext = "";
        return view('aiwriter::index', [ 'datatext' => $datatext]);
    }
	
	public function get_aicontent(Request $request)
	{
	   
	   $keyword = $request->input('keyword');
	   
	   
	   
	   
	   $request->validate([
							
		]);
		$rules = array(
		);
		 
		$messsages = array(
		      
	    );
		 
		$validator = Validator::make($request->all(), $rules,$messsages);
		
		if ($validator->fails()) 
		{
		 $failedRules = $validator->failed();
		 return back()->withErrors($validator);
		} 
		else
		{
		  
		  $result = Gemini::generativeModel(model: 'gemini-2.0-flash')->generateContent($keyword);

          $datatext =  $result->text(); // Hello! How can I assist you today?
		  return view('aiwriter::index', [ 'datatext' => $datatext]);
		 
          //return redirect()->back()->with('success', 'Update successfully.');
		  
		}
	
	}

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('aiwriter::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('aiwriter::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('aiwriter::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
}
