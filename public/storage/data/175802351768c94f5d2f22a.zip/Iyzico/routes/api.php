<?php

use Illuminate\Support\Facades\Route;
use Modules\Iyzico\Http\Controllers\IyzicoController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('iyzicos', IyzicoController::class)->names('iyzico');
});
