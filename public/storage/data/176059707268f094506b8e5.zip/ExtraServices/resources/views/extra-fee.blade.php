@if($xtra_setting->extra_service_status == 1)
<div class="card border-bottom-0 border-left-0 border-right-0 mb-4">
   @if(count($xtra_fee) != 0)
   <h6 class="mt-4"><strong>{{ __('Extra Services') }}</strong></h6>
    @foreach($xtra_fee as $xtra)
    @php $fee_service_id = base64_encode($xtra->ex_service_fee).'_'.base64_encode($xtra->ex_service_id); @endphp
    <div class="card-header d-flex justify-content-between align-items-center py-1 border-0">
       <div class="mb-0">
           <input type="checkbox" name="xtra_fee[]" class="custom-form-check-input" id="set-primary-1" value="{{ $fee_service_id }}">
        <label for="set-primary-1" class="form-check-label">{{ Helper::get_category_data($xtra->ex_service_id,'ex_service_name') }}</label>
        </div>
    <h5 class="mb-0 text-accent font-weight-normal"><span class="bg-faded-accent  rounded-sm py-1 px-2 fontsize17">{{ $allsettings->site_currency_symbol }} {{ $xtra->ex_service_fee }}</span></h5>
 </div>
 @endforeach
 @endif
</div>
@endif