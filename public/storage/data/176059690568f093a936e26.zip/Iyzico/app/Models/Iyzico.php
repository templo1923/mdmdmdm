<?php

namespace Modules\Iyzico\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Iyzico\Database\Factories\IyzicoFactory;

class Iyzico extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];
    
	public static function iyzico_Settings()
    {

    $value=DB::table('addon_iyzico_settings')->where('iyzico_id','=',1)->first(); 
    return $value;
	
    }
	
	public static function updateIyzicoSettings($data)
	{
    DB::table('addon_iyzico_settings')
      ->where('iyzico_id', 1)
      ->update($data);
    }
    
}
