<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]--><head>
@include('admin.stylesheet')
<link rel="stylesheet" type="text/css" href="{{ URL::to('Modules/Iyzico/resources/views/theme/style.css')}}">
</head>
<body>
    @include('admin.navigation')
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
       @include('admin.header')
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>{{ __('Iyzico Settings') }}</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    
                </div>
            </div>
        </div>
        @include('admin.warning')
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                           @if($demo_mode == 'on')
                           @include('admin.demo-mode')
                           @else
                           <form action="{{ route('admin.iyzico-settings') }}" method="post" id="setting_form" enctype="multipart/form-data">
                           {{ csrf_field() }}
                           @endif
                           <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                            <div class="form-group">
                                                <label for="site_loader_display" class="control-label mb-1">{{ __('Iyzico Active') }} <span class="require">*</span></label><br/>
                                                 <select name="iyzico_status" class="form-control" data-bvalidator="required">
                                                    <option value=""></option>
                                                    <option value="1" @if($iyzico_setting->iyzico_status == 1) selected @endif>Yes</option>
                                                    <option value="0" @if($iyzico_setting->iyzico_status == 0) selected @endif>No</option>
                                                 </select>
                                              </div>
                                              <div class="form-group">
                                                    <label for="site_title" class="control-label mb-1">{{ __('Iyzico Currency') }} <span class="require">*</span></label><br/>
                                                   <input id="iyzico_currency" name="iyzico_currency" type="text" class="form-control noscroll_textarea" value="{{ $iyzico_setting->iyzico_currency }}" data-bvalidator="required,minlen[3],maxlen[3]">
                                              </div>
                                              <div class="form-group">
                                                <label for="site_loader_display" class="control-label mb-1">{{ __('Iyzico Mode') }} <span class="require">*</span></label><br/>
                                                   <select name="iyzico_mode" id="iyzico_mode" class="form-control" data-bvalidator="required">
                                                    <option value=""></option>
                                                    <option value="1" @if($iyzico_setting->iyzico_mode == 1) selected @endif>Live</option>
                                                    <option value="0" @if($iyzico_setting->iyzico_mode == 0) selected @endif>Demo</option>
                                                    </select>
                                               </div>
                                      </div>
                                </div>
                               </div>
                            </div>
                            <div class="col-md-6">
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                          <div id="demomode" @if($iyzico_setting->iyzico_mode == 0) class="force-block alert alert-warning" @else class="force-none alert alert-warning" @endif>
                                          <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('Iyzico Test API Key') }} <span class="require">*</span></label><br/>
                                               <input id="iyzico_test_api_key" name="iyzico_test_api_key" type="text" class="form-control noscroll_textarea" value="{{ $iyzico_setting->iyzico_test_api_key }}" data-bvalidator="required">
                                             </div>
                                          <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('Iyzico Test Secret Key') }} <span class="require">*</span></label><br/>
                                               <input id="iyzico_test_secret_key" name="iyzico_test_secret_key" type="text" class="form-control noscroll_textarea" value="{{ $iyzico_setting->iyzico_test_secret_key }}" data-bvalidator="required">
                                             </div>
                                           </div>  
                                          <div id="livemode" @if($iyzico_setting->iyzico_mode == 1) class="force-block alert alert-primary" @else class="force-none alert alert-primary" @endif>   
                                          <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('Iyzico Live API Key') }} <span class="require">*</span></label><br/>
                                               <input id="iyzico_live_api_key" name="iyzico_live_api_key" type="text" class="form-control noscroll_textarea" value="{{ $iyzico_setting->iyzico_live_api_key }}" data-bvalidator="required">
                                             </div>
                                          <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('Iyzico Live Secret Key') }} <span class="require">*</span></label><br/>
                                               <input id="iyzico_live_secret_key" name="iyzico_live_secret_key" type="text" class="form-control noscroll_textarea" value="{{ $iyzico_setting->iyzico_live_secret_key }}" data-bvalidator="required">
                                             </div>
                                           </div>  
                                      </div>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-12 no-padding">
                             <div class="card-footer">
                                                        <button type="submit" name="submit" class="btn btn-primary btn-sm">
                                                            <i class="fa fa-dot-circle-o"></i> {{ __('Update') }}
                                                        </button>
                                                        <button type="reset" class="btn btn-danger btn-sm">
                                                            <i class="fa fa-ban"></i> {{ __('Reset') }}
                                                        </button>
                                                    </div>
                             
                             </div>
                            </form>
                        </div> 
                     </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
   </div><!-- /#right-panel -->
<!-- Right Panel -->
@include('admin.javascript')
<script type="text/javascript">
$(function () {
	    $("#iyzico_mode").change(function () {
		
		    if ($(this).val() == "1") 
			{
                
				$("#livemode").show();
				$("#demomode").hide();
				
            }
			else
			{
			   $("#livemode").hide();
			   $("#demomode").show();
			}
		
		});
	});
</script>	
</body>
</html>