<?php

namespace Modules\Backblaze\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Backblaze extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    public static function backblaze_Settings()
    {

    $value=DB::table('addon_backblaze_settings')->where('bb_id','=',1)->first(); 
    return $value;
	
    }
	
	public static function update_backblaze_Settings($data)
	{
    DB::table('addon_backblaze_settings')
      ->where('bb_id', 1)
      ->update($data);
    }
	
	
		
	
}
