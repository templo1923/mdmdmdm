<?php

use Illuminate\Support\Facades\Route;
use Modules\IDrive\Http\Controllers\IDriveController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('idrives', IDriveController::class)->names('idrive');
});
