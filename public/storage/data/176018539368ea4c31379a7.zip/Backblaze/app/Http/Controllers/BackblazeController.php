<?php

namespace Modules\Backblaze\Http\Controllers;

use DownGrade\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Backblaze\Models\Backblaze;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;
use Storage;


class BackblazeController extends Controller
{
    
	public function updateBackblaze($backblaze_access_key_id,$backblaze_secret_access_key,$backblaze_bucket_id,$backblaze_bucket_name)
	{
	    $data = array('backblaze_access_key_id' => $backblaze_access_key_id, 'backblaze_secret_access_key' => $backblaze_secret_access_key, 'backblaze_bucket_id' => $backblaze_bucket_id, 'backblaze_bucket_name' => $backblaze_bucket_name);
	    Backblaze::update_backblaze_Settings($data);
	}
	public function downloadBackblaze($blaze_file_name,$extension)
	{
	     $myFile = Storage::disk('b2')->get($blaze_file_name);
		 $newName = uniqid().time().'.'.$extension;
		 header("Cache-Control: public");
		 header("Content-Description: File Transfer");
		 header("Content-Disposition: attachment; filename=" . basename($newName));
		 header("Content-Type: application/octet-stream");
		 return readfile($myFile);
	}
	
	public function deleteBackblaze($blaze_file_name)
	{
	  Storage::disk('b2')->delete($blaze_file_name);
    }
	
	
}
