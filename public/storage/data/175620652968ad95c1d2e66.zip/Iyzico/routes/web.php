<?php

use Illuminate\Support\Facades\Route;
use Modules\Iyzico\Http\Controllers\IyzicoController;


Route::middleware(['XSS'])->group(function () {

Route::get('/admin/iyzico-settings', [IyzicoController::class, 'iyzico_settings']);
Route::post('/admin/iyzico-settings', [IyzicoController::class, 'update_iyzico_settings'])->name('admin.iyzico-settings');
Route::post('/admin/fetch-data', [AiWriterController::class, 'fetchData'])->name('admin.fetch-data');

});
