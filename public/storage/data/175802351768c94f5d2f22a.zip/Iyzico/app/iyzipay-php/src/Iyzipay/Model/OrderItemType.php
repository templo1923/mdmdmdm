<?php

namespace Iyzipay\Model;

class OrderItemType
{
    const PHYSICAL = "PHYSICAL";
    const VIRTUAL = "VIRTUAL";
}