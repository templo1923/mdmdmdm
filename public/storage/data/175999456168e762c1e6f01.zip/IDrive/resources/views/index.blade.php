<x-idrive::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('idrive.name') !!}</p>
</x-idrive::layouts.master>
