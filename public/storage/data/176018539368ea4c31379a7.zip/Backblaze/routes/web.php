<?php

use Illuminate\Support\Facades\Route;
use Modules\Backblaze\Http\Controllers\BackblazeController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('backblazes', BackblazeController::class)->names('backblaze');
});
