<?php

use Illuminate\Support\Facades\Route;
use Modules\ExtraServices\Http\Controllers\ExtraServicesController;

Route::middleware(['XSS'])->group(function () {
Route::get('/admin/extra-services', [ExtraServicesController::class, 'extra_services']);
Route::post('/admin/extra-services', [ExtraServicesController::class, 'update_extra_services'])->name('admin.extra-services');
Route::get('/admin/add-extra-service', [ExtraServicesController::class, 'add_extra_service']);
Route::post('/admin/add-extra-service', [ExtraServicesController::class, 'save_extra_service'])->name('admin.add-extra-service');
Route::get('/admin/extra-services/{id}', [ExtraServicesController::class, 'delete_extra_services']);
Route::get('/admin/edit-extra-service/{id}', [ExtraServicesController::class, 'edit_extra_services']);
Route::post('/admin/edit-extra-service', [ExtraServicesController::class, 'up_extra_service'])->name('admin.edit-extra-service');
Route::post('/admin/xtra-services', [ExtraServicesController::class, 'all_delete_extra_services'])->name('admin.xtra-services');

});

