<div class="col-md-12"><h5>{{ __('iDrive Storage Configuration (If idrive e2 storage selected)') }}</h5></div>
                             <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                       
                                        <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('IDRIVE ACCESS KEY ID') }}</label>
                                                <input id="idrive_access_key_id" name="idrive_access_key_id" type="text" class="form-control noscroll_textarea" value="{{ $idrive_setting->idrive_access_key_id }}">
                                            </div>
                                        
                                         <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('IDRIVE SECRET ACCESS KEY') }}</label>
                                                <input id="idrive_secret_access_key" name="idrive_secret_access_key" type="text" class="form-control noscroll_textarea" value="{{ $idrive_setting->idrive_secret_access_key }}"> 
                                            </div>
                                           <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('IDRIVE ENDPOINT') }}</label>
                                                <input id="idrive_endpoint" name="idrive_endpoint" type="text" class="form-control noscroll_textarea" value="{{ $idrive_setting->idrive_endpoint }}" data-bvalidator="url"> <small>Example : https://idrive.com</small>
                                            </div>
                                    </div>
                                </div>

                            </div>
                            </div>
                            
                            <div class="col-md-6">
                           
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                       
                                        <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('IDRIVE REGION') }}</label>
                                                <input id="idrive_region" name="idrive_region" type="text" class="form-control noscroll_textarea" value="{{ $idrive_setting->idrive_region }}">
                                                <small>Example : youridriveregion</small>
                                            </div>
                                        
                                         <div class="form-group">
                                                <label for="site_title" class="control-label mb-1">{{ __('IDRIVE BUCKET') }}</label>
                                                <input id="idrive_bucket" name="idrive_bucket" type="text" class="form-control noscroll_textarea" value="{{ $idrive_setting->idrive_bucket }}"> <small>Example : yourbucketname</small>
                                            </div>
                                           
                                    </div>
                                </div>

                            </div>
                            </div>